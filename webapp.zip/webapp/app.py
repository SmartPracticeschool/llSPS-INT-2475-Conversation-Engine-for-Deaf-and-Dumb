import numpy as np
import os
import cv2
from keras.models import load_model
from keras.preprocessing import image
import tensorflow as tf
global graph
graph = tf.get_default_graph()

from flask import Flask , request, render_template
from werkzeug.utils import secure_filename
from gevent.pywsgi import WSGIServer

from skimage.transform import resize
from gtts import gTTS

app = Flask(__name__)
model = load_model("Gesture_37.h5")

@app.route('/')
def index():
    return render_template('base.html')

@app.route('/predict',methods = ['GET','POST'])
def upload():
    if request.method == 'POST':
        f = request.files['image']
        print("current path")
        basepath = os.path.dirname(__file__)
        print("current path", basepath)
        filepath = os.path.join(basepath,'uploads',f.filename)
        print("upload folder is ", filepath)
        f.save(filepath)
        
        img_size=64
        img = cv2.imread(filepath)
        x = resize(img,(64,64,1))
        x = np.expand_dims(x,axis=0)
        
        with graph.as_default():
            preds = model.predict_classes(x)
            
            #print(preds)
            
        index = ['0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','_']
        
        output = "Hand Gesture is : " + str(index[preds[0]])
        import pyttsx3
        engine=pyttsx3.init()
        engine.say(output)
        engine.setProperty('rate',120)
        engine.setProperty('volume',0.9)
        engine.runAndWait()
    
    
    return output
if __name__ == '__main__':
    app.run(debug = True, threaded = False)
        
        
        
    
    
    